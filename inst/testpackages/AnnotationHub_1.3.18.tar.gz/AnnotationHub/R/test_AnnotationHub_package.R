.test <- function() BiocGenerics:::testPackage("AnnotationHub")
