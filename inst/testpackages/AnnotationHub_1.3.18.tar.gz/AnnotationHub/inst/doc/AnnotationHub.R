### R code from vignette source 'AnnotationHub.Rnw'

###################################################
### code chunk number 1: loadPkg
###################################################
library(AnnotationHub)


###################################################
### code chunk number 2: makeObject
###################################################
ah = AnnotationHub()


###################################################
### code chunk number 3: download1
###################################################
path <- "ah$goldenpath.hg19.encodeDCC.wgEncodeUwTfbs.wgEncodeUwTfbsMcf7CtcfStdPkRep1.narrowPeak_0.0.1.RData"


###################################################
### code chunk number 4: download2
###################################################
res <- ah$goldenpath.hg19.encodeDCC.wgEncodeUwTfbs.wgEncodeUwTfbsMcf7CtcfStdPkRep1.narrowPeak_0.0.1.RData


###################################################
### code chunk number 5: show
###################################################
ah


###################################################
### code chunk number 6: snapshot
###################################################
snapshotVersion(ah)
snapshotDate(ah)


###################################################
### code chunk number 7: possibleDates
###################################################
pd <- possibleDates(ah)
pd


###################################################
### code chunk number 8: setdate (eval = FALSE)
###################################################
## snapshotDate(ah) <- pd[1]


###################################################
### code chunk number 9: length
###################################################
length(ah)


###################################################
### code chunk number 10: listResources
###################################################
names <- head(names(ah),n=1)


###################################################
### code chunk number 11: namesShow1 (eval = FALSE)
###################################################
## names


###################################################
### code chunk number 12: listResources2
###################################################
urls <- head(snapshotUrls(ah),n=1)


###################################################
### code chunk number 13: urlsShow1 (eval = FALSE)
###################################################
## urls


###################################################
### code chunk number 14: baseFilters
###################################################
filters(ah)


###################################################
### code chunk number 15: columnsAndKeytypes
###################################################
columns(ah)
keytypes(ah)


###################################################
### code chunk number 16: keys
###################################################
head(keys(ah, keytype="Species"))


###################################################
### code chunk number 17: filtersSet
###################################################
filters(ah) <- list(Species="Homo sapiens")


###################################################
### code chunk number 18: listResources3
###################################################
length(ah)
names <- head(names(ah),n=1)


###################################################
### code chunk number 19: namesShow2 (eval = FALSE)
###################################################
## names


###################################################
### code chunk number 20: listResources4
###################################################
urls <- head(snapshotUrls(ah),n=1)


###################################################
### code chunk number 21: urlsShow2 (eval = FALSE)
###################################################
## urls


###################################################
### code chunk number 22: displayfunc (eval = FALSE)
###################################################
## d <- display(ah)


###################################################
### code chunk number 23: download3
###################################################
path <- "ah$goldenpath.hg19.encodeDCC.wgEncodeUwTfbs.wgEncodeUwTfbsMcf7CtcfStdPkRep1.narrowPeak_0.0.1.RData"


###################################################
### code chunk number 24: download4
###################################################
res <- ah$goldenpath.hg19.encodeDCC.wgEncodeUwTfbs.wgEncodeUwTfbsMcf7CtcfStdPkRep1.narrowPeak_0.0.1.RData


###################################################
### code chunk number 25: download3
###################################################
res


###################################################
### code chunk number 26: SessionInfo
###################################################
sessionInfo()


